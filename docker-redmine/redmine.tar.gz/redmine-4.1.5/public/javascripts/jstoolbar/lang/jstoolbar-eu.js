// jsToolBar EU language
// Author: Ales Zabala Alava (Shagi), <shagi@gisa-elkartea.org>
// 2010-01-25
// Distributed under the same terms as the jsToolBar itself.
jsToolBar.strings = {};
jsToolBar.strings['Strong'] = 'Lodia';
jsToolBar.strings['Italic'] = 'Etzana';
jsToolBar.strings['Underline'] = 'Azpimarra';
jsToolBar.strings['Deleted'] = 'Ezabatuta';
jsToolBar.strings['Code'] = 'Inline Code';
jsToolBar.strings['Heading 1'] = '1 Goiburua';
jsToolBar.strings['Heading 2'] = '2 Goiburua';
jsToolBar.strings['Heading 3'] = '3 Goiburua';
jsToolBar.strings['Highlighted code'] = 'Highlighted code';
jsToolBar.strings['Unordered list'] = 'Ordenatu gabeko zerrenda';
jsToolBar.strings['Ordered list'] = 'Ordenatutako zerrenda';
jsToolBar.strings['Quote'] = 'Aipamena';
jsToolBar.strings['Unquote'] = 'Aipamena kendu';
jsToolBar.strings['Preformatted text'] = 'Aurrez formateatutako testua';
jsToolBar.strings['Wiki link'] = 'Wiki orri baterako esteka';
jsToolBar.strings['Image'] = 'Irudia';
jsToolBar.strings['Edit'] = 'Editatu';
jsToolBar.strings['Preview'] = 'Aurreikusi';
